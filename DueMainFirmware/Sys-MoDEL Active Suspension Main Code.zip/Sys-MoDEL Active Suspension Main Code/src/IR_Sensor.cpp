/* 
* Sys-MoDEL Active Suspension IR_Sensor.cpp file
*
* Authors: Gregory Stewart, John Estafanos, Andrew Kennah, Patrick Laforest
* Creation Date: Jan 6, 2024
* Last Update: Jan 11, 2024
*
* Version 1.0
*
* Description: 
* This code is the IR_Sensor.cpp file that is used to calculate the vertical distance of the vehicle.  
*
* Functions & Descriptions: 
* Name: 
* Description: 
*
* References:
*
*/

#include "IR_Sensor.h"

IR_Sensor::IR_Sensor() 
{}

void IR_Sensor::begin()
{
    if (!vcnl4040.begin()) 
    {
        Serial.println("Couldn't find VCNL4040 chip");
        while (1);
    }
    Serial.println("Found VCNL4040 chip");

    // Initialize IR sensor for maximum sensitivity at greater ranges
    vcnl4040.setProximityLEDCurrent(VCNL4040_LED_CURRENT_200MA);
    vcnl4040.setProximityLEDDutyCycle(VCNL4040_LED_DUTY_1_40);
    vcnl4040.setAmbientIntegrationTime(VCNL4040_AMBIENT_INTEGRATION_TIME_640MS);
    vcnl4040.setProximityIntegrationTime(VCNL4040_PROXIMITY_INTEGRATION_TIME_8T);
    vcnl4040.setProximityHighResolution(true);
}

uint16_t IR_Sensor::GetProximity()
{
    proximity = vcnl4040.getProximity();
}