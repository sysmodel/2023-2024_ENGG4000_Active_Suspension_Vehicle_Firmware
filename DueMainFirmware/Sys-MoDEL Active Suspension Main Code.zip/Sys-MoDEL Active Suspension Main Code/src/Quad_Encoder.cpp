/* 
* Sys-MoDEL Active Suspension Quad_Encoder.cpp file
*
* Authors: Gregory Stewart, John Estafanos, Andrew Kennah, Patrick Laforest
* Creation Date: Jan 6, 2024
* Last Update: Jan 11, 2024
*
* Version 1.0
*
* Description: 
* This code is the Quad_Encoder.cpp file that is used to get data from the quadrature encoder. 
* Each retrieval of data is done by executing an internal ISR on the Arduino DUE. 
*
* Functions & Descriptions: 
* Name: 
* Description: 
*
* References:
*
*/

#include "Quad_Encoder.h"
#include "Encoder.h"

//Define Encoder Object
Encoder encoder(pinA, pinB);

// Function to calculate the speed of the quadrature encoder
void GetEncoderSpeed() {
    // Calculate encoder speed
    quadEncoderCount = encoder.read();
    quadEncoderTime = micros();

    quadEncoderVel = (double(quadEncoderCount - quadEncoderLastCount) * 2 * PI) / (double((quadEncoderTime - quadEncoderLastTime) * ppr * 1e-6)); 

    // Update lastCount and lastTime for the next calculation
    quadEncoderLastCount = quadEncoderCount;
    quadEncoderLastTime = quadEncoderTime;
}

