/* 
* Sys-MoDEL Active Suspension Main.ino file
*
* Authors: Gregory Stewart, John Estafanos, Andrew Kennah, Patrick Laforest
* Creation Date: Jan 6, 2024
* Last Update: Jan 11, 2024
*
* Version 1.0
*
* Description: 
* This code is the Main.ino file that is used to retrieve data from the array of sensors. 
* Each retrieval of data is done by executing an internal ISR on the Arduino DUE. 
*
* Functions & Descriptions: 
* Name: 
* Description: 
*
* References:
*
*/

#include <Arduino.h>
#include "DueTimer.h" 
#include "IR_Sensor.h"
#include "Quad_Encoder.h"

// Define variables 
uint16_t proximity; // Stores promimity value in (Unit) from IR sensor
double quadratureEncoderSpeed; // Stores the speed of the quatrature encoder in rad/s

// Define Objects
IR_Sensor irSensor;

void setup() {
  Serial.begin(115200);

  // Wait until serial port is opened
  while (!Serial) { delay(1); }

  // Initialize Timmer Interupts for 33Hz
  Timer1.attachInterrupt(GetProximityData).setFrequency(33).start(); // Timer for IR sensor
  Timer2.attachInterrupt(GetQuadEncoderData).setFrequency(33).start(); // Timer for Quad Encoder
}

void GetProximityData()
{
  proximity = irSensor.GetProximity();
}

void GetQuadEncoderData()
{
  GetEncoderSpeed();
  quadratureEncoderSpeed = quadEncoderVel;
}

void loop() {
  Serial.print("Proximity Data: ");
  Serial.println(proximity);
  delay(500);
}
