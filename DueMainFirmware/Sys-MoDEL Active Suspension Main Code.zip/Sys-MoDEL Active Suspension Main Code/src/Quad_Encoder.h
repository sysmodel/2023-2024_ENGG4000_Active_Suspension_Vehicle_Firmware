/* 
* Sys-MoDEL Active Suspension Quad_Encoder.h file
*
* Authors: Gregory Stewart, John Estafanos, Andrew Kennah, Patrick Laforest
* Creation Date: Jan 6, 2024
* Last Update: Jan 11, 2024
*
* Version 1.0
*
* Description: 
* This code is the Quad_Encoder.h file that is used to get data from the quadrature encoder. 
* Each retrieval of data is done by executing an internal ISR on the Arduino DUE. 
*
* Functions & Descriptions: 
* Name: 
* Description: 
*
* References:
*
*/
#ifndef Quad_Encoder_H
#define Quad_Encoder_H

#include <Arduino.h>
#include "DueTimer.h"
#include "Encoder.h"

// Define Variables
int pinA = 2; // Channel A on quadrature encoder
int pinB = 3; // Channel B on quadrature encoder
volatile int32_t quadEncoderLastCount = 0;
volatile int32_t quadEncoderCount = 0;
volatile unsigned long quadEncoderLastTime = micros();
volatile unsigned long quadEncoderTime = 0;
volatile double quadEncoderVel = 0;
int ppr = 2048;

// Create Function Prototypes
void GetEncoderSpeed();

#endif